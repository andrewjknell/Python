from zoo_animals import *

monkey = Monkey('rafiki',200)    
lion = Lion('mufasa',5,55)
lion.feed(50)
lion.display_all()
monkey.happiness()






